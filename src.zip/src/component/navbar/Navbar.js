import React from 'react';
import {   Link } from "react-router-dom";



import "./navbar.css"

const Navbar = () => {
  return (
    
    <div className="navbar">
      <div className="navContainer">
        <span className="logo">Railway Booking</span>
        <div className="navItems">
       
        <Link className="navButton"  to="/login">
              Login
            </Link>
           
           
            <Link className="navButton"  to="/admin">
              Admin signin
            </Link>
            <Link className="navButton"  to="/admindashboard">
              Admin Dashboard
            </Link>
            <Link className="navButton" to="/register">
              Register
            </Link>
        </div>
      </div>
      <div className="container mt-3">
       
        </div>
    </div>
    
  )
}

export default Navbar