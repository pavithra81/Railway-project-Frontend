
import React, { Component } from "react";

import axios from "axios";
import {  Link } from "react-router-dom";

import { Navigate } from 'react-router';

export default class AddTrain extends Component {
  state = {
    trainId:"",
    trainName:"",
    source:"",
    destination:"",
    pricePerKms:"",
    route:[
        {
            routeId:"",
            stationName:"",
            timeOfArrival:"",
            timeOfDeparture:"",
            totalDistance:"",
        },
    ],
    daysOfRunning:[],
    totalNumOfSeats:"",
    trainClasses:[
        {
            className:"",
            price:"",
            numOfSeats:"",
        },],
    isTrainCreated: false
  };

  handleTrainid = event => {
    const { value } = event.target;
    if (value != null) {
      this.setState({ trainId: value.toUpperCase() });
    }
  };


  handleTrainName = event => {
    const { value } = event.target;
    if (value != null) {
      this.setState({ trainName: value.toUpperCase() });
    }
  };

  handlesource = event => {
    const { value } = event.target;
    this.setState({ source: value.toUpperCase() });
  };

  handledestination = event => {
    const { value } = event.target;
    this.setState({ destination: value.toUpperCase() });
  };
  handlepricePerKms= event => {
    const { value } = event.target;
    this.setState({ pricePerKms: value.toUpperCase() });
  };

  handleroute = event => {
    const { value } = event.target;
    this.setState({ route: value.toUpperCase() });
  };

  handlerouteid = event => {
    const { value } = event.target;
    this.setState({ routeId: value.toUpperCase() });
  };
  handlestationname = event => {
    const { value } = event.target;
    this.setState({ stationName: value.toUpperCase() });
  };
  handletimeofarrival = event => {
    const { value } = event.target;
    this.setState({ timeOfArrival: value.toUpperCase() });
  };
  handletimeOfDeparture = event => {
    const { value } = event.target;
    this.setState({ timeOfDeparture: value.toUpperCase() });
  };
  

  handletotaldistance = event => {
    const { value } = event.target;
    this.setState({ totalDistance: value.toUpperCase() });
  };
  
  handledaysofrunning = event => {
    const { value } = event.target;
    this.setState({ daysOfRunning: value.toUpperCase() });
  };
  handletotalnumofseats = event => {
    const { value } = event.target;
    this.setState({ totalNumOfSeats: value.toUpperCase() });
  };
  handletrainclasses = event => {
    const { value } = event.target;
    this.setState({ trainClasses: value.toUpperCase() });
  };
 
  handleclassname = event => {
    const { value } = event.target;
    this.setState({ className: value.toUpperCase() });
  };
  handleprice = event => {
    const { value } = event.target;
    this.setState({ price: value.toUpperCase() });
  };
  handlenumofseats = event => {
    const { value } = event.target;
    this.setState({ numOfSeats: value.toUpperCase() });
  };
  



  
  
  




  handleSubmit = event => {
    event.preventDefault();

    const newTrain = {
      trainid: this.state.trainId,
      trainName: this.state.trainName,
      source:this.state.source,
      destination:this.state.destination,
      pricePerKms:this.state.pricePerKms,
      route:this.state.route,
      routeId:this.state.route.routeId,
      stationName:this.state.route.stationName,
      timeOfArrival:this.state.route.timeOfArrival,
      timeOfDeparture:this.state.route.timeOfDeparture,
      totalDistance:this.state.route.totalDistance,
      daysOfRunning:this.state.daysOfRunning,
      totalNumOfSeats:this.state.totalNumOfSeats,
      trainClasses:this.state.trainClasses,
      className:this.state.trainClasses.className,
      price:this.state.trainClasses.price,
      numOfSeats:this.state.trainClasses.numOfSeats




     
    
    };

    axios
      .post(
        "/TRAIN-MANAGEMENT-SERVICE/train/addtrain",
        newTrain
      )
      .then(response => response)
      .catch(error => error.message);

    window.alert("Train created successfully");
    this.setState({
        trainid: "",
        trainName: "",
        source:"",
    destination:"",
    pricePerKms:"",
    route:[
        {
            routeId:"",
            stationName:"",
            timeOfArrival:"",
            timeOfDeparture:"",
            totalDistance:"",
        },],
        daysOfRunning:[],
        totalNumOfSeats:"",
        trainClasses:[
            {
                className:"",
                price:"",
                numOfSeats:"",
            },
        
    ],
    
      isTrainCreated: true
    });
  };

  render() {
   // if (this.state.isTrainCreated) {
    //  return <Navigate to="/trainlist" />;
   // }
   

    return (
      <div>
        
        <div className="d-flex justify-content-center">
          <div className="card bg-light mb-3">
            <div className="card-header">
              <h3 className="d-flex justify-content-center">Create Train</h3>
            </div>
            <div className="card-body">
              <h5 className="card-title">
                <form onSubmit={this.handleSubmit}>
                  <div className="form-row">
                    <div className="col">
                      <label htmlFor="trainNumber">Train Id</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainid"
                        onChange={this.handleTrainid}
                        value={this.state.trainId}
                        required
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="trainName">Train Name</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handleTrainName}
                        value={this.state.trainName}
                        required
                      />
                    </div>
                  </div>
                  <br />
                  <div className="form-row">
                    <div className="col">
                      <label htmlFor="inputState">Source</label>
                      <input
                        id="from"
                        className="form-control"
                        onChange={this.handlesource}
                        value={this.state.source}
                        required
                      />
                    </div>

                    <div className="col">
                      <label htmlFor="inputState">Destination</label>
                      <input
                        id="to"
                        className="form-control"
                        onChange={this.handledestination}
                        value={this.state.destination}
                        required
                      />
                    </div>


                    <div className="col">
                      <label htmlFor="inputState">Price per kms</label>
                      <input
                        id="to"
                        className="form-control"
                        onChange={this.handlepricePerKms}
                        value={this.state.pricePerKms}
                        required
                      />
                    </div>

                    <div className="col">
                      <label htmlFor="trainName">route id</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handlerouteid}
                        value={this.state.route.routeId}
                        required
                      />
                    </div>
                    <div className="col">
                      <label htmlFor="trainName">station name</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handlestationname}
                        value={this.state.route.stationName}
                        required
                      />
                    </div>


                    <div className="col">
                      <label htmlFor="trainName">Time of arrival</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handletimeofarrival}
                        value={this.state.route.timeOfArrival}
                        required
                      />
                    </div>

                    
                    <div className="col">
                      <label htmlFor="trainName">Time of Departure</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handletimeOfDeparture}
                        value={this.state.route.timeOfDeparture}
                        required
                      />
                    </div>
   
   
                   
                    <div className="col">
                      <label htmlFor="trainName">days running</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handledaysofrunning}
                        value={this.state.daysOfRunning}
                        required
                      />
                    </div>

                    

                    
                    <div className="col">
                      <label htmlFor="trainName">total no seats</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handletotalnumofseats}
                        value={this.state.totalNumOfSeats}
                        required
                      />
                    </div>

                    
                    <div className="col">
                      <label htmlFor="trainName">classname</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handleclassname}
                        value={this.state.className}
                        required
                      />
                    </div>

                    
                    <div className="col">
                      <label htmlFor="trainName">price</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handleprice}
                        value={this.state.price}
                        required
                      />
                    </div>

                    
                    <div className="col">
                      <label htmlFor="trainName">no of seats</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handlenumofseats}
                        value={this.state.numOfSeats}
                        required
                      />
                    </div>

                  






                  </div>
                  <br />
                
              
                  <br />
                  <div>
                    <button
                      type="submit"
                      value="createTicket"
                      className="btn btn-dark btn-lg btn-block"
                    >
                      Create Train
                    </button>
                    
                    <p>Delete Train?<Link to="/delTrain"> Click Here</Link></p>
                  </div>
                </form>
              </h5>
            </div>
          </div>
        </div>
      </div>
    );
  }
}


/* <div className="col">
                      <label htmlFor="trainName">Total distance</label>
                      <input
                        type="name"
                        className="form-control"
                        id="trainName"
                        onChange={this.handletotaldistance}
                        value={this.state.totalDistance}
                        required
                      />
                      
                    </div>*/