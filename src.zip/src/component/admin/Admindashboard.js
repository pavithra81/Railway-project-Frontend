import React from 'react';
import {   Link } from "react-router-dom";
const Admindashoard = () => {
  return (
    
    <div className="navbar">
      <div className="navContainer">
        <span className="logo">Admin dashboard</span>
        <div className="navItems">
      
        <Link className="navButton"  to="/bookingform">
              booking form
            </Link>
           
            <Link className="navButton"  to="/addtrain">
              Add Train
            </Link>
            <Link className="navButton"  to="/booking">
              Booking
            </Link>
           
           
            <Link className="navButton"  to="/trainlist">
              Train List
            </Link>
            <Link className="navButton"  to="/jwttoken">
              jwt
            </Link>
            
        </div>
      </div>
      <div className="container mt-3">
       
        </div>
    </div>
    
  )
}

export default Admindashoard;