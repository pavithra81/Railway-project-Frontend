import React,{Component} from 'react';
class LoginAdmin extends Component{
  constructor()
  {
    super();
    this.state={
      userName:null,
      password:null
      
    }
  }
  login()
  { 
    console.log();
    fetch('/admin/auth/signin',{
      method:'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body:JSON.stringify(this.state)

    }).then((response)=>{

      response.json((result)=>{
        console.log("hello");
        console.log(result.token);
        console.warn("result",result);
        localStorage.setItem('login',JSON.stringify({
          login:true,
          token:result.token,
          
        }))
        this.setState({login:true})
        
      })
    });
  }
  render(){
    return(
      <div>
        <h1>jwt token</h1>
       
         
        <label>UserName</label>
          <input type="text" onChange={(event)=>{this.setState({userName:event.target.value})}}/><br></br>
          <label>Password</label>
          <input type="text" onChange={(event)=>{this.setState({password:event.target.value})}}/><br></br>
          <button onClick={()=>{this.login()}}>Login</button>
          
         


      </div>
    )
  }
}

export default LoginAdmin;












//{
         // !this.state.login?
       //  :
       //  <div><button onClick={()=>{this.dashboard()}}>Dashboard</button></div>
        //}





































/*import React from 'react';
import  { useState } from 'react';
const Loginadmin=()=>
{
    const[userName,setuserName]=useState('')
    const[password,setpassword]=useState('')
    const handleLogin= async()=>{
       let result = await fetch ("/admin/auth/signin",{
method:'POST',
body:JSON.stringify({userName,password}),
headers:{
    'Content-Type':'application/json;'
}
       });
       result= await result.json();
       console.warn(result);

    }
    return(
      <div >
      <span className="loginTitle">   heloooo Login</span>
      <form className="loginForm">
        <label>UserName</label>
        <input className="loginInput" type="text"placeholder="Enter your email..."  onChange={(e)=>setuserName(e.target.value)} value={userName}/>
        <p><label>Password</label>
        <input className="loginInput" type="password"  
        placeholder="Enter your password..."  onChange={(e)=>setpassword(e.target.value)} value={password}/></p>
        <button onClick={handleLogin} className="loginButton">Login</button>
      </form> 
    </div>

    )
}

export default Loginadmin;
*/