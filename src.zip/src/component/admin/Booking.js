import React from 'react';
import {   Link } from "react-router-dom";
const booking = () => {
  return (
    
    <div className="navbar">
      <div className="navContainer">
        <span className="logo">Admin dashboard</span>
        <div className="navItems">
      
        <Link className="navButton"  to="/bookingform">
              booking form
            </Link>
           
            
            
            
        </div>
      </div>
      <div className="container mt-3">
       
        </div>
    </div>
    
  )
}

export default booking;