import Loginadmin from './component/admin/Loginadmin';
import Navbar from './component/navbar/Navbar';
import './App.css';
import  Home  from './component/home/Home';
import React from 'react';
import Jwttoken from './component/admin/Jwttoken';
import AdminDashboard from './component/admin/Admindashboard';
import TrainList from './component/admin/TrainList'
import TrainDetails from './component/admin/TrainDetails';
import AddTrain from './component/admin/AddTrain';
import BookingForm from './component/booking/BookingForm';
import Booking from './component/admin/Booking';
import HomeSlider  from './component/slider/Slider';

import Admin from "./Admin";
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
import TrainListbyId from './component/admin/TrainListbyId';
import UpdateTrain from './component/admin/UpdateTrain';


function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/loginadmin" element={<Loginadmin/>}/>
      <Route path="navbar/" element={<Navbar/>}/>
      <Route path="/jwttoken" element={<Jwttoken/>}/>
      <Route path="/admindashboard" element={<AdminDashboard/>}/>
      <Route path="/trainlist" element={<TrainList/>}/>
      <Route path="/trains/:trainId" element={<TrainDetails/>}/>
      <Route path="/addtrain" element={<AddTrain/>}/>
      <Route path="/bookingform" element={<BookingForm/>}/>
      <Route path="/booking" element={<Booking/>}/>
      <Route path="/trainlistbyid" element={<TrainListbyId/>}/>
      <Route path="/home"  element={<HomeSlider/>} />
      <Route path="adminlogin/" exact element={<adminSignIn/>} />
      <Route path="/admin"  component={Admin}/>
      <Route path="/updatetrain"  component={UpdateTrain}/>
    </Routes>
  </BrowserRouter>
  );
}

export default App;
